
const user = {
  state: {
    token: '',
    name: "",
    avatar: "",
    role: "",
    phone: ""
  },

  mutations: {
  },

  actions: {

  }
};

export default user;
